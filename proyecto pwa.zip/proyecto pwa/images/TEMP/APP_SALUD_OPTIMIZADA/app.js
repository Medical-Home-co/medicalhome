document.addEventListener('DOMContentLoaded', () => {
    // --- Configuración y Elementos Principales ---
    const screens = document.querySelectorAll('.page');
    const sideMenu = document.getElementById('side-menu');
    const menuOverlay = document.getElementById('menu-overlay');
    // Selecciona todas las barras de navegación inferior
    const allNavBars = document.querySelectorAll('[id^="bottom-nav-"]');

    // Mapeo de IDs de modales y sus funciones de cierre
    const modalConfig = {
        'med-modal': { closer: () => closeModal('med-modal'), formId: 'med-form' },
        'appointment-modal': { closer: () => closeModal('appointment-modal'), formId: 'appointment-form' },
        'contact-modal': { closer: () => closeModal('contact-modal'), formId: 'contact-form' },
        'diabetes-modal': { closer: () => closeModal('diabetes-modal'), formId: 'diabetes-form' },
        'tea-modal': { closer: () => closeModal('tea-modal'), formId: 'tea-form' },
        'arthritis-modal': { closer: () => closeModal('arthritis-modal'), formId: 'arthritis-form' },
        'bcm-modal': { closer: () => closeModal('bcm-modal'), formId: 'bcm-form' }
    };

    // --- Funciones de Utilidad ---

    // 1. Navegación entre pantallas
    const navigateTo = (screenId, navItem = null) => {
        screens.forEach(screen => screen.classList.add('hidden'));
        const targetScreen = document.getElementById(screenId);
        if (targetScreen) {
            targetScreen.classList.remove('hidden');
        }
        window.scrollTo(0, 0);

        // Limpiar el estado activo de todos los nav-items
        document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));

        if (navItem) {
            // Activar el elemento de navegación proporcionado (desde la barra inferior)
            navItem.classList.add('active');
        } else {
             // Si no se proporcionó un navItem (ej. desde el menú lateral),
             // busca el navItem que corresponde a la pantalla actual en la barra de navegación adecuada.
             const screenName = screenId.split('-screen')[0];
             const currentNav = document.getElementById(`bottom-nav-${screenName}`);
             if(currentNav) {
                const activeItem = currentNav.querySelector(`[data-screen="${screenId}"]`);
                if(activeItem) {
                    activeItem.classList.add('active');
                }
             }
        }
    };

    // 2. Control de Modales
    const openModal = (modalId) => document.getElementById(modalId).classList.remove('hidden');
    const closeModal = (modalId) => document.getElementById(modalId).classList.add('hidden');

    // 3. Control del Menú Lateral
    const closeSideMenu = () => {
        sideMenu.classList.remove('open');
        menuOverlay.classList.add('opacity-0');
        setTimeout(() => menuOverlay.classList.add('hidden'), 300);
    };
    const toggleSideMenu = () => {
        const isOpen = sideMenu.classList.toggle('open');
        if (isOpen) {
            menuOverlay.classList.remove('hidden');
            setTimeout(() => menuOverlay.classList.remove('opacity-0'), 10);
        } else {
            closeSideMenu();
        }
    };

    // 4. Notificación Toast
    const showToast = (message, isError = false) => {
        const toast = document.getElementById('notification-toast');
        const toastMessage = document.getElementById('toast-message');
        toastMessage.textContent = message;

        toast.classList.remove('hidden', 'bg-green-500', 'bg-red-500');
        toast.classList.add(isError ? 'bg-red-500' : 'bg-green-500');

        setTimeout(() => toast.classList.add('hidden'), 4000);
    };

    // 5. Manejo de Envío de Formularios (Simulación)
    const handleFormSubmit = (e, modalCloser) => {
        e.preventDefault();
        modalCloser();
        showToast('¡Registro guardado con éxito!');
        return false;
    };

    // --- Configuración de Event Listeners ---
    const setupEventListeners = () => {
        // Navegación de login
        document.getElementById('login-btn').addEventListener('click', () => navigateTo('summary-screen'));
        document.getElementById('guest-login-btn').addEventListener('click', () => navigateTo('summary-screen'));
        document.getElementById('create-user-btn').addEventListener('click', () => navigateTo('create-user-screen'));
        document.getElementById('back-to-login-btn').addEventListener('click', () => navigateTo('login-screen'));
        document.getElementById('logout-btn').addEventListener('click', () => navigateTo('login-screen'));

        // Control del Menú Lateral
        document.querySelector('.toggle-menu-btn').addEventListener('click', toggleSideMenu);
        menuOverlay.addEventListener('click', closeSideMenu);
        
        // Navegación de la barra inferior (Delegación de eventos)
        allNavBars.forEach(navBar => {
            navBar.addEventListener('click', (e) => {
                const navItem = e.target.closest('.nav-item');
                if (navItem) {
                    const screenId = navItem.dataset.screen;
                    navigateTo(screenId, navItem);
                }
            });
        });

        // Eventos del Menú Lateral (Botones de navegación)
        document.getElementById('side-menu').addEventListener('click', (e) => {
            const button = e.target.closest('button[data-screen]');
            if(button) {
                const screenId = button.dataset.screen;
                navigateTo(screenId);
                closeSideMenu();
            }
        });


        // Abrir Modales (Usando data-open-modal)
        document.querySelectorAll('[data-open-modal]').forEach(btn => {
            btn.addEventListener('click', () => openModal(btn.dataset.openModal));
        });

        // Configuración de Cierre de Modales y Envío de Formularios
        Object.keys(modalConfig).forEach(modalId => {
            const config = modalConfig[modalId];
            const modalElement = document.getElementById(modalId);

            // Cerrar modal al hacer clic en cualquier elemento con data-close-modal dentro del modal
            modalElement.querySelectorAll('[data-close-modal]').forEach(closeBtn => {
                closeBtn.addEventListener('click', config.closer);
            });

            // Enviar formulario (Manejo de la simulación y cierre)
            document.getElementById(config.formId).addEventListener('submit', (e) => handleFormSubmit(e, config.closer));
        });

        // Cierre de Toast
        document.getElementById('close-toast').addEventListener('click', () => document.getElementById('notification-toast').classList.add('hidden'));
    };

    // Inicialización
    setupEventListeners();
    navigateTo('login-screen');
});