// Requiere Node.js 16+
// Instala dependencias ejecutando: npm install fs path archiver prettier

const fs = require("fs");
const path = require("path");
const prettier = require("prettier");
const archiver = require("archiver");

// Ruta de archivos
const inputFile = path.join(__dirname, "separacion_chatgpt.html");
const outputFile = path.join(__dirname, "index_heroicons.html");
const zipFile = path.join(__dirname, "index_heroicons.zip");

// Mapeo de íconos Lucide → Heroicons
const iconMap = {
  "lucide-heart-pulse": "heart",
  "lucide-droplets": "beaker",
  "lucide-pipette": "test-tube",
  "lucide-brain-circuit": "light-bulb",
  "lucide-dna": "finger-print",
  "lucide-stethoscope": "user-circle",
  "lucide-calendar-check": "calendar-days",
  "lucide-calendar-days": "calendar-days",
  "lucide-pill": "capsule",
  "lucide-contact-2": "phone",
  "lucide-menu": "bars-3",
  "lucide-x": "x-mark",
  "lucide-bell": "bell",
  "lucide-log-out": "arrow-right-on-rectangle",
  "lucide-hand-heart": "hand-thumb-up",
  "lucide-settings": "cog-6-tooth",
  "lucide-lungs": "lungs", // Pulmonar (nuevo)
};

// Cargar archivo original
let html = fs.readFileSync(inputFile, "utf8");

// Reemplazar íconos Lucide con Heroicons genéricos (SVG inline)
for (const [lucideClass, heroName] of Object.entries(iconMap)) {
  const regex = new RegExp(
    `<svg[^>]*class="[^"]*${lucideClass}[^"]*"[^>]*>[\\s\\S]*?<\\/svg>`,
    "g"
  );
  html = html.replace(regex, `<svg data-heroicon="${heroName}" class="w-6 h-6 text-gray-500"></svg>`);
}

// Agregar ícono pulmonar si no existe
if (!html.includes("Pulmonar")) {
  html = html.replace(
    /(<\/nav>|<\/menu>|<\/header>)/i,
    `
    <div class="flex items-center gap-2 text-teal-400">
      <svg data-heroicon="lungs" class="w-6 h-6 text-teal-400"></svg>
      <span>Pulmonar</span>
    </div>
    $1
  `
  );
}

// Formatear HTML con Prettier
const formattedHtml = prettier.format(html, { parser: "html" });

// Guardar nuevo HTML
fs.writeFileSync(outputFile, formattedHtml, "utf8");
console.log("✅ Archivo index_heroicons.html generado correctamente.");

// Crear archivo ZIP
const output = fs.createWriteStream(zipFile);
const archive = archiver("zip", { zlib: { level: 9 } });

output.on("close", () =>
  console.log(`📦 Archivo ZIP creado: ${zipFile} (${archive.pointer()} bytes)`)
);

archive.pipe(output);
archive.file(outputFile, { name: "index_heroicons.html" });
archive.finalize();
