        document.addEventListener('DOMContentLoaded', () => {
            // --- Populate TEA Modal Dynamic Content ---
            const populateTeaModal = () => {
                const moodContainer = document.getElementById('tea-mood-container');
                const socialContainer = document.getElementById('tea-social-container');
                const triggersContainer = document.getElementById('tea-sensory-triggers-container');

                if (moodContainer) {
                    const moods = ['😠', '😟', '😐', '😊', '🤩'];
                    moodContainer.innerHTML = moods.map((emoji, index) => `
                        <div class="text-center">
                            <input type="radio" id="mood-${index}" name="mood" value="${emoji}" class="sr-only emoji-radio">
                            <label for="mood-${index}" class="text-4xl cursor-pointer p-2 rounded-lg border-2 border-transparent emoji-radio-label">${emoji}</label>
                        </div>
                    `).join('');
                }
                
                if (socialContainer) {
                    const socialInteractions = ['Positivas', 'Neutrales', 'Con Dificultad'];
                    socialContainer.innerHTML = socialInteractions.map((type, index) => `
                        <div>
                            <input type="checkbox" name="socialInteractions" value="${type}" id="social-${index}" class="sr-only btn-checkbox">
                            <label for="social-${index}" class="btn-checkbox-label text-sm">${type}</label>
                        </div>
                    `).join('');
                }
                
                if (triggersContainer) {
                    const sensoryTriggers = ['Ruidos fuertes', 'Luces brillantes', 'Multitudes', 'Texturas', 'Olores fuertes'];
                    triggersContainer.innerHTML = sensoryTriggers.map((trigger, index) => `
                        <div>
                            <input type="checkbox" name="sensoryTriggers" value="${trigger}" id="trigger-${index}" class="sr-only btn-checkbox">
                            <label for="trigger-${index}" class="btn-checkbox-label text-sm">${trigger}</label>
                        </div>
                    `).join('');
                }
            };
            populateTeaModal();

            // --- FUNCIONES AUXILIARES ---
            const getFutureDateTime = (days, hours, minutes) => {
                const date = new Date();
                date.setDate(date.getDate() + days);
                date.setHours(hours);
                date.setMinutes(minutes);
                date.setSeconds(0);
                return date.toISOString().slice(0, 16);
            };
            const getPastDateTime = (days, hours, minutes) => {
                const date = new Date();
                date.setDate(date.getDate() - days);
                date.setHours(hours);
                date.setMinutes(minutes);
                return date.toISOString().slice(0, 16);
            };

            // --- ESTADO Y DATOS DE LA APLICACIÓN ---
            let state = {
                currentPage: 'login-screen',
                medications: [],
                appointments: [],
                contacts: [],
                diabetesRecords: [],
                arthritisRecords: [],
                teaRecords: [], // Nuevo estado para TEA
                bcm: {
                    records: [],
                    pesoSeco: null,
                    pesoActual: null,
                    limiteDiario: null,
                    citasPesoSeco: []
                }
            };

            // --- SELECTORES DE ELEMENTOS DEL DOM ---
            const pages = document.querySelectorAll('.page');
            const sideMenu = document.getElementById('side-menu');
            const menuOverlay = document.getElementById('menu-overlay');
            const closeMenuBtn = document.getElementById('close-menu-btn');
            const sideMenuItems = document.querySelectorAll('.side-menu-item');
            const appContent = document.getElementById('app-content');
            const bottomNavContainer = document.getElementById('bottom-nav-container');

            // --- DECLARACIÓN DE FUNCIONES ---

            const updateNav = (currentPageId) => {
                const navDestinations = ['summary', 'meds', 'appointments', 'agenda', 'diabetes', 'arthritis', 'tea', 'bienestar', 'conditions', 'bcm'];
                navDestinations.forEach(dest => {
                    const navElement = document.getElementById(`bottom-nav-${dest}`);
                    if(navElement) {
                        navElement.innerHTML = bottomNavContainer.innerHTML;
                        const navItems = navElement.querySelectorAll('.nav-item');
                        navItems.forEach(item => {
                             item.classList.remove('active');
                            if(item.dataset.page === currentPageId) {
                                item.classList.add('active');
                            }
                            if(item.dataset.page) {
                                if (item.dataset.page === 'menu-screen') {
                                    item.addEventListener('click', toggleMenu);
                                } else {
                                    item.addEventListener('click', () => navigateTo(item.dataset.page));
                                }
                            }
                        });
                    }
                });
            };
            
            const renderAll = () => {
                if(state.currentPage !== 'login-screen' && state.currentPage !== 'create-user-screen') {
                    renderMedsList();
                    renderAppointmentsList();
                    renderAgendaScreen();
                    renderDiabetesScreen();
                    renderArthritisScreen();
                    renderTeaScreen();
                    renderBienestarScreen();
                    renderBcmScreen();
                    renderSummary();
                }
            };
            
            const initApp = () => {
                renderAll();
                // Comprueba recordatorios cada minuto
                setInterval(checkReminders, 60000);
                // Actualiza el resumen cada minuto
                setInterval(renderSummary, 60000);
            };

            const navigateTo = (pageId) => {
                pages.forEach(page => page.classList.add('hidden'));
                const targetPage = document.getElementById(pageId);
                
                if (!targetPage) {
                    console.error(`Navigation error: Page with ID "${pageId}" not found.`);
                    return;
                }
                targetPage.classList.remove('hidden');

                const isAuthPage = pageId === 'login-screen' || pageId === 'create-user-screen';
                
                if(!isAuthPage){
                    updateNav(pageId);
                }
                
                if (sideMenu.classList.contains('open')) {
                    toggleMenu();
                }
                
                state.currentPage = pageId;
                window.scrollTo(0, 0);
            };

            const toggleMenu = () => {
                sideMenu.classList.toggle('open');
                if (sideMenu.classList.contains('open')) {
                    menuOverlay.classList.remove('hidden');
                    menuOverlay.style.opacity = '1';
                } else {
                    menuOverlay.style.opacity = '0';
                    setTimeout(() => menuOverlay.classList.add('hidden'), 300);
                }
            };
            
            const handleLogin = () => {
                navigateTo('summary-screen');
                initApp();
            };

            // --- RENDER FUNCTIONS (ALL DECLARED BEFORE USE) ---

            const renderMedsList = () => {
                const content = document.getElementById('meds-content');
                const headerAddBtn = document.getElementById('add-med-btn-header');

                if (state.medications.length === 0) {
                    headerAddBtn.classList.add('hidden');
                    content.innerHTML = `
                        <div class="text-center mt-16 flex flex-col items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pill text-gray-400 mb-4"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/></svg>
                            <h2 class="text-xl font-bold text-gray-700">Aún no tienes medicamentos guardados</h2>
                            <p class="text-gray-500 mt-2 max-w-xs mx-auto">Comienza agregando tus medicamentos para recibir recordatorios y llevar un mejor control.</p>
                            <button id="add-med-btn-empty" class="mt-6 flex items-center gap-2 px-6 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                                Agregar Medicamento
                            </button>
                        </div>
                    `;
                    document.getElementById('add-med-btn-empty').addEventListener('click', openMedModal);
                } else {
                    headerAddBtn.classList.remove('hidden');
                    content.innerHTML = state.medications.map(med => `
                        <div class="bg-white p-4 rounded-2xl shadow-sm mb-4">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h3 class="text-lg font-bold text-gray-800">${med.name}</h3>
                                    <p class="text-gray-500">${med.dose} • ${med.frequency}</p>
                                </div>
                                <div class="flex items-center gap-3 text-gray-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-square-pen"><path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4Z"/></svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-trash-2 text-red-500"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                                </div>
                            </div>
                            <div class="flex items-center justify-between mt-4">
                                <div class="flex items-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clock text-gray-500"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                    <div class="flex gap-2 flex-wrap">
                                        ${med.times.map(time => `<span class="bg-gray-100 text-gray-700 font-medium px-3 py-1 rounded-md text-sm">${time}</span>`).join('')}
                                    </div>
                                </div>
                            </div>
                            <div class="flex justify-between items-center mt-4 pt-4 border-t border-gray-100">
                                 <div class="flex items-center gap-2 text-gray-600 font-medium">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bell"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
                                    Recordatorios
                                 </div>
                                 <label class="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" value="" class="sr-only peer" ${med.reminders ? 'checked' : ''}>
                                    <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                 </label>
                            </div>
                        </div>
                    `).join('');
                }
                document.getElementById('meds-count').textContent = `${state.medications.length} activos`;
            };

            const renderAppointmentsList = () => {
                const content = document.getElementById('appointments-content');
                const headerAddBtn = document.getElementById('add-appointment-btn-header');
                const now = new Date();

                if (state.appointments.length === 0) {
                    headerAddBtn.classList.add('hidden');
                    content.innerHTML = `
                        <div class="text-center mt-16 flex flex-col items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-calendar-x-2 text-gray-400 mb-4"><path d="M21 13V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8"/><path d="M8 2v4"/><path d="M16 2v4"/><path d="M3 10h18"/><path d="m17 17 5 5"/><path d="m22 17-5 5"/></svg>
                            <h2 class="text-xl font-bold text-gray-700">Aún no tienes citas programadas</h2>
                            <p class="text-gray-500 mt-2 max-w-xs mx-auto">Comienza agregando tus citas médicas para recibir recordatorios oportunos.</p>
                            <button id="add-appointment-btn-empty" class="mt-6 flex items-center gap-2 px-6 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                                Agregar Cita
                            </button>
                        </div>
                    `;
                    document.getElementById('add-appointment-btn-empty').addEventListener('click', openAppointmentModal);
                } else {
                    headerAddBtn.classList.remove('hidden');
                    const upcoming = state.appointments.filter(a => new Date(a.datetime) >= now).sort((a,b) => new Date(a.datetime) - new Date(b.datetime));
                    const past = state.appointments.filter(a => new Date(a.datetime) < now).sort((a,b) => new Date(b.datetime) - new Date(a.datetime));

                    content.innerHTML = `
                        <h2 class="text-lg font-semibold text-gray-700 mt-2 mb-2">Próximas Citas</h2>
                        ${upcoming.length > 0 ? upcoming.map(renderAppointmentCard).join('') : '<p class="text-gray-500 text-center py-4 bg-white rounded-xl">No hay citas próximas.</p>'}
                        <h2 class="text-lg font-semibold text-gray-700 mt-6 mb-2">Citas Pasadas</h2>
                        ${past.length > 0 ? past.map(renderAppointmentCard).join('') : '<p class="text-gray-500 text-center py-4 bg-white rounded-xl">No hay citas pasadas.</p>'}
                    `;
                }
                 document.getElementById('appointments-count').textContent = `${state.appointments.filter(a => new Date(a.datetime) >= now).length} próximas`;
            }

            const renderAppointmentCard = (appointment) => {
                const date = new Date(appointment.datetime);
                const isPast = date < new Date();
                return `
                    <div class="bg-white p-4 rounded-2xl shadow-sm mb-3 ${isPast ? 'opacity-60' : ''}">
                         <div class="flex items-center gap-4">
                             <div class="flex flex-col items-center justify-center bg-cyan-100 text-cyan-700 font-bold w-16 h-16 rounded-xl">
                                 <span class="text-sm -mb-1">${date.toLocaleString('es-ES', { month: 'short' })}</span>
                                 <span class="text-3xl">${date.getDate()}</span>
                             </div>
                             <div>
                                <h3 class="font-bold text-gray-800">${appointment.reason}</h3>
                                <p class="text-sm text-gray-500">${appointment.doctor}</p>
                                <p class="text-sm text-cyan-600 font-semibold mt-1">${date.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}</p>
                             </div>
                         </div>
                    </div>
                `;
            }

            const renderAgendaScreen = () => {
                const content = document.getElementById('agenda-content');
                
                if(state.contacts.length === 0) {
                    content.innerHTML = `
                        <div class="text-center mt-16 flex flex-col items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users-round text-gray-400 mb-4"><path d="M18 21a8 8 0 0 0-12 0"/><circle cx="12" cy="11" r="4"/><path d="M6 21a2 2 0 0 1-2-2v-1a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v1a2 2 0 0 1-2 2Z"/></svg>
                            <h2 class="text-xl font-bold text-gray-700">Aún no tienes contactos guardados</h2>
                            <p class="text-gray-500 mt-2 max-w-xs mx-auto">Agrega médicos, familiares y contactos importantes.</p>
                            <button id="add-contact-btn-empty" class="mt-6 flex items-center gap-2 px-6 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                                Agregar Primer Contacto
                            </button>
                        </div>
                    `;
                    document.getElementById('add-contact-btn-empty').addEventListener('click', openContactModal);
                } else {
                    content.innerHTML = `
                        <button id="add-contact-btn-header" class="w-full flex items-center justify-center gap-2 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                            Agregar Contacto
                        </button>
                        <div class="space-y-3">
                            ${state.contacts.map(contact => `
                                <div class="bg-white p-4 rounded-xl shadow-sm">
                                    <div class="flex items-start gap-3">
                                        <div class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 font-bold">
                                            ${contact.name.charAt(0)}
                                        </div>
                                        <div>
                                            <h3 class="font-bold text-gray-800">${contact.name}</h3>
                                            <p class="text-sm text-gray-500">${contact.role}</p>
                                        </div>
                                    </div>
                                    <div class="mt-3 flex justify-between items-center">
                                        <a href="tel:${contact.phone}" class="text-gray-700 font-semibold">${contact.phone}</a>
                                        <div class="flex items-center gap-3">
                                            <a href="tel:${contact.phone}" class="text-gray-400 hover:text-blue-600"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg></a>
                                            <a href="sms:${contact.phone}" class="text-gray-400 hover:text-blue-600"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-message-square-text"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M13 8H7"/><path d="M17 12H7"/></svg></a>
                                        </div>
                                    </div>
                                    ${contact.notes ? `<div class="text-xs text-gray-600 mt-2 bg-gray-50 p-2 rounded-md"><b>Notas:</b> ${contact.notes}</div>` : ''}
                                    <div class="flex items-center gap-2 mt-3 pt-3 border-t border-gray-100">
                                        <button class="flex-1 text-sm py-2 bg-gray-100 rounded-lg font-semibold text-gray-700">Editar</button>
                                        <button class="flex-1 text-sm py-2 bg-red-100 rounded-lg font-semibold text-red-600">Eliminar</button>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    `;
                     document.getElementById('add-contact-btn-header').addEventListener('click', openContactModal);
                }
            };

            const renderDiabetesScreen = () => {
                const content = document.getElementById('diabetes-content');

                if (state.diabetesRecords.length === 0) {
                    content.innerHTML = `
                        <div class="text-center mt-16 flex flex-col items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-activity text-gray-400 mb-4"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                            <h2 class="text-xl font-bold text-gray-700">Comienza tu control de diabetes</h2>
                            <p class="text-gray-500 mt-2 max-w-xs mx-auto">Registra tus niveles de glucosa y medicación.</p>
                            <button id="add-diabetes-btn-empty" class="mt-6 flex items-center gap-2 px-6 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                                Primer Registro
                            </button>
                        </div>
                    `;
                    document.getElementById('add-diabetes-btn-empty').addEventListener('click', openDiabetesModal);
                } else {
                    content.innerHTML = `
                        <button id="add-diabetes-btn-header" class="w-full flex items-center justify-center gap-2 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                            Nuevo Registro
                        </button>
                        <div class="space-y-3">
                            ${state.diabetesRecords.map(rec => {
                                const date = new Date(rec.datetime);
                                const status = getGlucoseStatus(rec.glucose);
                                return `
                                <div class="bg-white p-4 rounded-xl shadow-sm">
                                    <div class="flex justify-between items-start mb-2">
                                        <p class="text-2xl font-bold text-gray-800">${rec.glucose} mg/dL</p>
                                        <span class="text-xs font-semibold px-2 py-1 rounded-full ${status.classes}">${status.text}</span>
                                    </div>
                                    <div class="text-sm text-gray-500 space-y-1">
                                        <p><strong>Fecha:</strong> ${date.toLocaleDateString('es-ES')}</p>
                                        <p><strong>Hora:</strong> ${date.toLocaleTimeString('es-ES', {hour: '2-digit', minute: '2-digit'})}</p>
                                        ${rec.hba1c ? `<p><strong>HbA1c:</strong> ${rec.hba1c}%</p>` : ''}
                                        ${rec.insulin ? `<p><strong>Insulina:</strong> ${rec.insulin} unidades</p>` : ''}
                                        ${rec.notes ? `<p><strong>Notas:</strong> ${rec.notes}</p>` : ''}
                                    </div>
                                    <div class="flex items-center gap-2 mt-4 pt-3 border-t border-gray-100">
                                        <button class="flex-1 text-sm py-2 bg-gray-100 rounded-lg font-semibold text-gray-700">Editar</button>
                                        <button class="flex-1 text-sm py-2 bg-red-100 rounded-lg font-semibold text-red-600">Eliminar</button>
                                    </div>
                                </div>
                                `
                            }).join('')}
                        </div>
                    `;
                    document.getElementById('add-diabetes-btn-header').addEventListener('click', openDiabetesModal);
                }
            };
            
            const getGlucoseStatus = (level) => {
                if (level < 70) return { text: 'Bajo', classes: 'bg-blue-100 text-blue-800' };
                if (level <= 140) return { text: 'Normal', classes: 'bg-green-100 text-green-800' };
                return { text: 'Alto', classes: 'bg-red-100 text-red-800' };
            };

             const renderArthritisScreen = () => {
                const content = document.getElementById('arthritis-content');

                if (state.arthritisRecords.length === 0) {
                    content.innerHTML = `
                        <div class="text-center mt-16 flex flex-col items-center">
                           <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-activity text-gray-400 mb-4"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                            <h2 class="text-xl font-bold text-gray-700">Comienza tu seguimiento de artritis</h2>
                            <p class="text-gray-500 mt-2 max-w-xs mx-auto">Registra tus síntomas y medicación diaria.</p>
                            <button id="add-arthritis-btn-empty" class="mt-6 flex items-center gap-2 px-6 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                                Primer Registro
                            </button>
                        </div>
                    `;
                    document.getElementById('add-arthritis-btn-empty').addEventListener('click', openArthritisModal);
                } else {
                     content.innerHTML = `
                        <button id="add-arthritis-btn-header" class="w-full flex items-center justify-center gap-2 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                            Nuevo Registro
                        </button>
                        <div class="space-y-3">
                            ${state.arthritisRecords.map(rec => {
                                const date = new Date(rec.datetime);
                                const pain = getPainInfo(rec.painLevel);
                                const mobility = getMobilityInfo(rec.mobilityLimitation);
                                return `
                                <div class="bg-white p-4 rounded-xl shadow-sm">
                                    <div class="flex justify-between items-center mb-3">
                                        <p class="font-bold text-gray-800">${date.toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                                        <div class="flex gap-2">
                                            <span class="text-xs font-semibold px-2 py-1 rounded-full" style="background-color: ${pain.color}; color: ${pain.textColor}">${pain.text}</span>
                                            <span class="text-xs font-semibold px-2 py-1 rounded-full" style="background-color: ${mobility.color}; color: ${mobility.textColor}">${rec.mobilityLimitation}</span>
                                        </div>
                                    </div>
                                    <div class="text-sm text-gray-600 space-y-2">
                                        <div class="grid grid-cols-2 gap-2">
                                            <p><strong>Rigidez matutina:</strong> ${rec.morningStiffness ? 'Sí' : 'No'}</p>
                                            <p><strong>Inflamación:</strong> ${rec.visibleSwelling ? 'Sí' : 'No'}</p>
                                        </div>
                                        ${rec.joints.length > 0 ? `<div><strong>Articulaciones:</strong><div class="flex flex-wrap gap-2 mt-1">${rec.joints.map(j => `<span class="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded-full">${j}</span>`).join('')}</div></div>` : ''}
                                        ${rec.meds.length > 0 ? `<div><strong>Medicamentos:</strong><div class="flex flex-wrap gap-2 mt-1">${rec.meds.map(m => `<span class="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full">${m}</span>`).join('')}</div></div>` : ''}
                                        ${rec.notes ? `<p class="pt-2"><strong>Notas:</strong> ${rec.notes}</p>` : ''}
                                    </div>
                                    <div class="flex items-center gap-2 mt-4 pt-3 border-t border-gray-100">
                                        <button class="flex-1 text-sm py-2 bg-gray-100 rounded-lg font-semibold text-gray-700">Editar</button>
                                        <button class="flex-1 text-sm py-2 bg-red-100 rounded-lg font-semibold text-red-600">Eliminar</button>
                                    </div>
                                </div>
                                `
                            }).join('')}
                        </div>
                    `;
                    document.getElementById('add-arthritis-btn-header').addEventListener('click', openArthritisModal);
                }
            };

            const getPainInfo = (level) => {
                const value = parseInt(level);
                const colors = ['#d6eadf', '#dff0d8', '#ecf3d4', '#fae8b0', '#f9e0a2', '#f7d894', '#f5cf86', '#f2c678', '#f0bd6a', '#eeb55c', '#eac4d5'];
                const textColor = (value < 4) ? '#3c763d' : (value < 8) ? '#8a6d3b' : '#a94442';
                const textLevels = ["Sin dolor", "Leve", "Leve", "Leve", "Moderado", "Moderado", "Moderado", "Moderado", "Severo", "Severo", "Severo"];
                return {
                    text: `${textLevels[value]} (${value}/10)`,
                    color: colors[value],
                    textColor: textColor
                };
            };
            
            const getMobilityInfo = (level) => {
                 const colors = {
                    'Leve': { color: '#d6eadf', textColor: '#3c763d'},
                    'Moderada': { color: '#fae8b0', textColor: '#8a6d3b'},
                    'Severa': { color: '#eac4d5', textColor: '#a94442'}
                };
                return colors[level];
            };
            
            const renderTeaScreen = () => {
                const content = document.getElementById('tea-content');

                if (state.teaRecords.length === 0) {
                    content.innerHTML = `
                        <div class="text-center mt-16 flex flex-col items-center">
                           <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-puzzle text-gray-400 mb-4"><path d="M19.435 7.49a2.338 2.338 0 0 0-2.338-2.338H14.41a2.34 2.34 0 1 0-4.68 0H7.043a2.34 2.34 0 0 0 0 4.68h2.684a2.34 2.34 0 1 1 0 4.68H7.043a2.34 2.34 0 1 0 0 4.68h2.684a2.34 2.34 0 1 0 4.68 0h2.684a2.34 2.34 0 1 0 0-4.68h-2.684a2.34 2.34 0 1 1 0-4.68h2.684a2.338 2.338 0 0 0 2.338-2.338Z"/></svg>
                            <h2 class="text-xl font-bold text-gray-700">Comienza tu seguimiento diario</h2>
                            <p class="text-gray-500 mt-2 max-w-xs mx-auto">Registra estados de ánimo, interacciones y rutinas para un mejor entendimiento.</p>
                            <button id="add-tea-btn-empty" class="mt-6 flex items-center gap-2 px-6 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                                Primer Registro
                            </button>
                        </div>
                    `;
                    document.getElementById('add-tea-btn-empty').addEventListener('click', openTeaModal);
                } else {
                     content.innerHTML = `
                        <button id="add-tea-btn-header" class="w-full flex items-center justify-center gap-2 py-3 text-white font-semibold rounded-lg shadow-md btn-gradient mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                            Nuevo Registro Diario
                        </button>
                        <div class="space-y-3">
                           ${state.teaRecords.map(rec => {
                                const date = new Date(rec.datetime);
                                return `
                                <div class="bg-white p-4 rounded-xl shadow-sm">
                                    <div class="flex justify-between items-center mb-3">
                                        <p class="font-bold text-gray-800">${date.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
                                        <span class="text-3xl">${rec.mood || ''}</span>
                                    </div>
                                    <div class="space-y-3 text-sm">
                                        ${rec.positiveMoment ? `<div class="bg-green-50 text-green-800 p-3 rounded-lg"><strong>✨ Logro del día:</strong> ${rec.positiveMoment}</div>` : ''}
                                        <div><strong>Emociones:</strong> Ansiedad nivel ${rec.anxietyLevel}/10. ${rec.emotionNotes}</div>
                                        <div><strong>Interacciones:</strong> ${rec.socialInteractions.join(', ') || 'Ninguna'}. ${rec.socialNotes}</div>
                                        <div><strong>Sensorial:</strong> Sobrecarga: ${rec.sensoryOverload}. ${rec.sensoryTriggers.length > 0 ? `Disparadores: ${rec.sensoryTriggers.join(', ')}.` : ''} ${rec.sensoryNotes}</div>
                                        <div><strong>Rutina:</strong> Cambio: ${rec.routineChange}. Manejo: ${rec.changeHandling}. ${rec.routineNotes}</div>
                                        <div><strong>Descanso y Comida:</strong> Sueño ${rec.sleepQuality} (${rec.sleepHours}h). Apetito ${rec.appetite}. ${rec.foodNotes}</div>
                                        <div><strong>Intereses:</strong> Comportamientos repetitivos: ${rec.stimming}. Interés especial: ${rec.specialInterest}.</div>
                                    </div>
                                     <div class="flex items-center gap-2 mt-4 pt-3 border-t border-gray-100">
                                        <button class="flex-1 text-sm py-2 bg-gray-100 rounded-lg font-semibold text-gray-700">Editar</button>
                                        <button class="flex-1 text-sm py-2 bg-red-100 rounded-lg font-semibold text-red-600">Eliminar</button>
                                    </div>
                                </div>
                                `
                           }).join('')}
                        </div>
                     `;
                    document.getElementById('add-tea-btn-header').addEventListener('click', openTeaModal);
                }
            };

            const renderBienestarScreen = () => {
                const content = document.getElementById('bienestar-content');
                const wellnessData = [
                    { 
                        title: 'Cuidados para Hipertensión', 
                        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-heart-pulse text-red-500"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l.7-1 2.1 4.3 2.1-4.3.7 1h6.28"/></svg>',
                        items: [
                            { title: 'Alimentación', text: 'Reduce el consumo de sal (menos de 2.3g por día)\nAumenta el consumo de frutas y verduras\nLimita el alcohol y cafeína\nEvita alimentos procesados y enlatados\nPrefiere carnes magras y pescado' },
                            { title: 'Ejercicio', text: 'Camina al menos 30 minutos diarios\nPractica ejercicios aeróbicos moderados\nEvita ejercicios de alta intensidad sin supervisión\nIncluye ejercicios de relajación como yoga\nMantén un peso saludable' },
                            { title: 'Monitoreo', text: 'Mide tu presión arterial regularmente\nLleva un registro de tus lecturas\nToma tus medicamentos como fueron prescritos\nControla tu peso semanalmente\nAsiste a citas médicas regulares' }
                        ]
                    },
                    { 
                        title: 'Cuidados para Enfermedad Renal', 
                        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-droplets text-sky-500"><path d="M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.7-3.02C8.23 8.5 8 7.2 8 6c0-2.2 1.8-4 4-4s4 1.8 4 4c0 1.2-.23 2.5-1.3 3.23-.95.64-1.7 1.86-1.7 3.02 0 2.23 1.8 4.05 4 4.05"/><path d="M12 22s7-4 7-10c0-3.87-3.13-7-7-7s-7 3.13-7 7c0 6 7 10 7 10z"/></svg>',
                        items: [
                            { title: 'Alimentación', text: 'Controla la ingesta de líquidos según indicación médica\nLimita el consumo de potasio (bananos, naranjas, tomates)\nReduce el fósforo (lácteos, frutos secos)\nModera las proteínas según indicación médica\nEvita alimentos con alto contenido de sodio' },
                            { title: 'Cuidados Generales', text: 'Mantén el acceso vascular limpio y seco\nNo uses joyas ni ropa ajustada en el brazo de la fístula\nReporta cualquier signo de infección inmediatamente\nSigue estrictamente el horario de diálisis\nPésate diariamente y registra los cambios' },
                            { title: 'Monitoreo', text: 'Controla tu peso entre sesiones\nMonitora la producción de orina\nVigila signos de sobrecarga de líquidos\nRevisa regularmente tu acceso vascular\nMantén actualizados tus análisis de laboratorio' }
                        ]
                    },
                     { 
                        title: 'Cuidados para Diabetes', 
                        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pipette text-emerald-500"><path d="m2 22 1-1h3l9-9"/><path d="M3 21v-3l9-9"/><path d="m15 6 3.4-3.4a2.1 2.1 0 1 1 3 3L18 9l.4.4c.9.9.9 2.5 0 3.4l-2.1 2.1c-.9.9-2.5.9-3.4 0L12.5 15l-1-1Z"/></svg>',
                        items: [
                            { title: 'Alimentación', text: 'Controla las porciones y horarios de comida\nLimita carbohidratos simples y azúcares\nIncluye fibra en cada comida\nPrefiere granos integrales\nMantén horarios regulares de alimentación' },
                            { title: 'Monitoreo', text: 'Mide tu glucosa según indicación médica\nRegistra los resultados en un diario\nConoce los síntomas de hipo e hiperglucemia\nLleva siempre contigo una fuente de glucosa\nRevisa tus pies diariamente' },
                            { title: 'Cuidados Generales', text: 'Toma tus medicamentos puntualmente\nRota los sitios de inyección de insulina\nMantén un peso corporal saludable\nEjercítate regularmente\nCuida la higiene de tus pies' }
                        ]
                    },
                     { 
                        title: 'Cuidados para el Espectro Autista (TEA)', 
                        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-brain-circuit text-purple-500"><path d="M12 5a3 3 0 1 0-5.993.25"/><path d="M12 5a3 3 0 1 1 5.993.25"/><path d="M15 13a3 3 0 1 0-5.993.25"/><path d="M15 13a3 3 0 1 1 5.993.25"/><path d="M9 13a3 3 0 1 1-5.993.25"/><path d="M6.007 13.25A3 3 0 1 0 9 13"/><path d="M12 21a3 3 0 1 0-5.993-.25"/><path d="M12 21a3 3 0 1 1 5.993.25"/><path d="M6.243 8.515A3 3 0 0 0 4.231 9.87a2.98 2.98 0 0 0-1.933 2.898"/><path d="M17.757 8.515A3 3 0 0 1 19.769 9.87a2.98 2.98 0 0 1 1.933 2.898"/><path d="M9.243 16.515A3 3 0 0 0 7.231 17.87a2.98 2.98 0 0 0-1.933 2.898"/><path d="M14.757 16.515A3 3 0 0 1 16.769 17.87a2.98 2.98 0 0 1 1.933 2.898"/><path d="M13.25 5.007A3 3 0 0 1 12 7a3 3 0 0 1-1.25-1.993"/><path d="M13.25 13.007A3 3 0 0 1 12 15a3 3 0 0 1-1.25-1.993"/><path d="M10.75 13.007A3 3 0 0 0 12 15a3 3 0 0 0 1.25-1.993"/><path d="M4.231 12.768A3 3 0 0 1 6 12a3 3 0 0 1 1.768.768"/><path d="M19.769 12.768A3 3 0 0 0 18 12a3 3 0 0 0-1.768.768"/><path d="M7.231 20.768A3 3 0 0 1 9 20a3 3 0 0 1 1.768.768"/><path d="M16.769 20.768A3 3 0 0 0 15 20a3 3 0 0 0-1.768.768"/></svg>',
                        items: [
                            { title: 'Comunicación y Entorno', text: 'Usar lenguaje claro, literal y directo.\nProporcionar instrucciones visuales (pictogramas, horarios).\nCrear un ambiente tranquilo, reduciendo estímulos sensoriales excesivos.\nOfrecer espacios seguros y de calma donde puedan retirarse.\nAnticipar cambios y comunicarlos con antelación.' },
                            { title: 'Rutinas y Estructura', text: 'Establecer rutinas diarias predecibles y consistentes.\nUtilizar calendarios o agendas visuales para las actividades del día.\nDividir tareas complejas en pasos más pequeños y manejables.\nFomentar intereses y pasatiempos como herramientas de aprendizaje.\nOfrecer opciones limitadas para evitar sobrecarga en decisiones.' },
                            { title: 'Apoyo Social y Terapéutico', text: 'Buscar terapias especializadas (ocupacional, del lenguaje, ABA).\nEnseñar habilidades sociales de forma explícita.\nFomentar la interacción en grupos pequeños y estructurados.\nValidar sus emociones y ayudar a identificar y gestionar la ansiedad.\nConectar con grupos de apoyo para familias y cuidadores.' }
                        ]
                    },
                    { 
                        title: 'Cuidados para Artritis', 
                        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-dna text-amber-500"><path d="M2 15c6.667-6 13.333 0 20-6"/><path d="M9 22c1.798-1.998 2.518-3.999 2-6-1.54-5.997-5.52-5.996-7 0-1.328 5.38.74 6 2 6"/><path d="M22 8c-6.667 6-13.333 0-20 6"/><path d="M15 2c-1.798 1.998-2.518 3.999-2 6 1.54 5.997 5.52 5.996 7 0 1.328-5.38-.74-6-2-6"/></svg>',
                        items: [
                           { title: 'Ejercicio', text: 'Ejercicios de rango de movimiento diarios\nNatación o ejercicios en agua tibia\nCaminatas suaves y regulares\nEjercicios de fortalecimiento muscular\nYoga o tai chi para flexibilidad' },
                           { title: 'Manejo del Dolor', text: 'Aplica calor antes del ejercicio\nUsa frío después de la actividad\nDescansa las articulaciones cuando duelan\nAlterna períodos de actividad y descanso\nUsa dispositivos de apoyo cuando sea necesario' },
                           { title: 'Cuidados Diarios', text: 'Mantén un peso corporal saludable\nUsa técnicas de protección articular\nAdapta tu hogar para reducir el esfuerzo\nToma medicamentos según prescripción\nMantente activo dentro de tus límites' }
                        ]
                    }
                ];
                
                content.innerHTML = `
                    <div class="bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 rounded-lg mb-6">
                        <h4 class="font-bold">Información Importante</h4>
                        <p class="text-sm">Esta información es de carácter educativo y no sustituye el consejo médico profesional. Siempre consulta con tu médico antes de hacer cambios en tu tratamiento o estilo de vida.</p>
                    </div>
                    ${wellnessData.map(category => `
                        <div class="bg-white p-4 rounded-2xl shadow-sm mb-3">
                            <h3 class="font-bold text-gray-800 text-lg flex items-center gap-3">${category.icon} ${category.title}</h3>
                            <div class="mt-3 space-y-1">
                                ${category.items.map(item => `
                                    <div class="accordion-item">
                                        <button class="accordion-header flex justify-between items-center w-full text-left py-2 text-gray-700 font-semibold border-t">
                                            <span>${item.title}</span>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-down transition-transform duration-300"><path d="m6 9 6 6 6-6"/></svg>
                                        </button>
                                        <div class="accordion-content overflow-hidden max-h-0 transition-all duration-300 ease-in-out">
                                            <ul class="list-disc list-inside pt-1 pb-3 pl-2 text-gray-600 text-sm space-y-1">
                                                ${item.text.split('\n').map(line => `<li>${line.trim()}</li>`).join('')}
                                            </ul>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `).join('')}
                `;

                const accordionItems = content.querySelectorAll('.accordion-item');
                accordionItems.forEach(item => {
                    const header = item.querySelector('.accordion-header');
                    header.addEventListener('click', () => {
                        const content = item.querySelector('.accordion-content');
                        const icon = header.querySelector('svg');
                        const isOpen = content.style.maxHeight && content.style.maxHeight !== '0px';

                        // Close all accordions in the same card
                        const parentCard = item.closest('.bg-white');
                        parentCard.querySelectorAll('.accordion-item').forEach(otherItem => {
                            if (otherItem !== item) {
                                otherItem.querySelector('.accordion-content').style.maxHeight = '0px';
                                otherItem.querySelector('.accordion-header svg').classList.remove('rotate-180');
                            }
                        });
                        
                        if (isOpen) {
                            content.style.maxHeight = '0px';
                            icon.classList.remove('rotate-180');
                        } else {
                            content.style.maxHeight = content.scrollHeight + 'px';
                            icon.classList.add('rotate-180');
                        }
                    });
                });
            };
            
            const renderBcmScreen = () => {
                // Esta función se mantiene igual
            };
            
            const renderSummary = () => {
                // Esta función se mantiene igual
            };

            // MODAL DE CONTACTO
            const contactModal = document.getElementById('contact-modal');
            const contactModalContent = contactModal.querySelector('.bg-white');
            const contactForm = document.getElementById('contact-form');

            const openContactModal = () => {
                contactModal.classList.remove('hidden');
                setTimeout(() => contactModalContent.classList.remove('translate-y-full'), 10);
            }
            const closeContactModal = () => {
                contactModalContent.classList.add('translate-y-full');
                setTimeout(() => {
                    contactModal.classList.add('hidden');
                    contactForm.reset();
                }, 300);
            }
            
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(contactForm);
                const newContact = {
                    id: Date.now(),
                    name: formData.get('name'),
                    role: formData.get('role'),
                    phone: formData.get('phone'),
                    notes: formData.get('notes'),
                };
                state.contacts.push(newContact);
                closeContactModal();
                renderAll();
            });

            // MODAL DE DIABETES
            const diabetesModal = document.getElementById('diabetes-modal');
            const diabetesModalContent = diabetesModal.querySelector('.bg-white');
            const diabetesForm = document.getElementById('diabetes-form');

            const openDiabetesModal = () => {
                diabetesModal.classList.remove('hidden');
                setTimeout(() => diabetesModalContent.classList.remove('translate-y-full'), 10);
            }
            const closeDiabetesModal = () => {
                diabetesModalContent.classList.add('translate-y-full');
                setTimeout(() => {
                    diabetesModal.classList.add('hidden');
                    diabetesForm.reset();
                }, 300);
            }
            
            diabetesForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(diabetesForm);
                const newRecord = {
                    id: Date.now(),
                    datetime: new Date().toISOString(),
                    glucose: formData.get('glucose'),
                    hba1c: formData.get('hba1c'),
                    insulin: formData.get('insulin'),
                    notes: formData.get('notes'),
                };
                state.diabetesRecords.push(newRecord);
                closeDiabetesModal();
                renderAll();
            });

            // MODAL DE ARTRITIS
            const arthritisModal = document.getElementById('arthritis-modal');
            const arthritisModalContent = arthritisModal.querySelector('.bg-white');
            const arthritisForm = document.getElementById('arthritis-form');
            const painLevelSelect = document.getElementById('pain-level-select');
            const mobilityLevelSelect = document.getElementById('mobility-level-select');
            
            // Populate pain level select
            const painLevels = ["0 - Sin dolor", "1 - Leve", "2 - Leve", "3 - Leve", "4 - Moderado", "5 - Moderado", "6 - Moderado", "7 - Moderado", "8 - Severo", "9 - Severo", "10 - Severo"];
            if(painLevelSelect.options.length === 0) { // Evita duplicar opciones en recargas
                painLevels.forEach((level, index) => {
                    const option = document.createElement('option');
                    option.value = index;
                    option.textContent = level;
                    painLevelSelect.appendChild(option);
                });
            }

            const updateColor = (selectElement, infoFunction) => {
                const info = infoFunction(selectElement.value);
                selectElement.style.backgroundColor = info.color;
                selectElement.style.color = info.textColor || 'black';
                selectElement.style.fontWeight = 'bold';
            }

            painLevelSelect.addEventListener('change', () => updateColor(painLevelSelect, (val) => getPainInfo(val)));
            mobilityLevelSelect.addEventListener('change', () => updateColor(mobilityLevelSelect, (val) => getMobilityInfo(val)));


            const openArthritisModal = () => {
                arthritisModal.classList.remove('hidden');
                updateColor(painLevelSelect, (val) => getPainInfo(val));
                updateColor(mobilityLevelSelect, (val) => getMobilityInfo(val));
                setTimeout(() => arthritisModalContent.classList.remove('translate-y-full'), 10);
            }
            const closeArthritisModal = () => {
                arthritisModalContent.classList.add('translate-y-full');
                setTimeout(() => {
                    arthritisModal.classList.add('hidden');
                    arthritisForm.reset();
                    document.getElementById('arthritis-meds-container').innerHTML = '';
                    painLevelSelect.style.backgroundColor = '';
                    painLevelSelect.style.color = '';
                    mobilityLevelSelect.style.backgroundColor = '';
                    mobilityLevelSelect.style.color = '';
                }, 300);
            }

             arthritisForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(arthritisForm);
                const joints = [];
                formData.getAll('joints').forEach(j => joints.push(j));

                const meds = [];
                document.querySelectorAll('#arthritis-meds-container > div').forEach(tag => {
                    meds.push(tag.dataset.medName);
                });
                
                const newRecord = {
                    id: Date.now(),
                    datetime: new Date().toISOString(),
                    painLevel: formData.get('painLevel'),
                    morningStiffness: formData.has('morningStiffness'),
                    visibleSwelling: formData.has('visibleSwelling'),
                    joints: joints,
                    mobilityLimitation: formData.get('mobilityLimitation'),
                    meds: meds,
                    notes: formData.get('notes'),
                };
                state.arthritisRecords.push(newRecord);
                closeArthritisModal();
                renderAll();
            });

            // Lógica para agregar medicamentos en modal de artritis
            const addArthritisMedBtn = document.getElementById('add-arthritis-med-btn');
            const arthritisMedInput = document.getElementById('arthritis-med-input');
            const arthritisMedsContainer = document.getElementById('arthritis-meds-container');

            const addArthritisMedTag = (medName) => {
                if (!medName.trim()) return;
                const tag = document.createElement('div');
                tag.className = 'bg-blue-100 text-blue-800 text-sm font-semibold px-2.5 py-1 rounded-full flex items-center gap-2';
                tag.innerHTML = `
                    <span>${medName}</span>
                    <button type="button" class="remove-med-tag font-bold text-blue-600 hover:text-blue-800">&times;</button>
                `;
                tag.dataset.medName = medName;
                
                tag.querySelector('.remove-med-tag').addEventListener('click', () => {
                    tag.remove();
                });

                arthritisMedsContainer.appendChild(tag);
                arthritisMedInput.value = '';
                arthritisMedInput.focus();
            };

            addArthritisMedBtn.addEventListener('click', () => {
                addArthritisMedTag(arthritisMedInput.value);
            });
            
            arthritisMedInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    addArthritisMedTag(arthritisMedInput.value);
                }
            });
            
            // MODAL DE TEA
            const teaModal = document.getElementById('tea-modal');
            const teaModalContent = teaModal.querySelector('.bg-white');
            const teaForm = document.getElementById('tea-form');
            const anxietySlider = document.getElementById('anxiety-level');
            const anxietyValue = document.getElementById('anxiety-level-value');

            anxietySlider.addEventListener('input', () => {
                anxietyValue.textContent = anxietySlider.value;
            });

            const openTeaModal = () => {
                teaModal.classList.remove('hidden');
                setTimeout(() => teaModalContent.classList.remove('translate-y-full'), 10);
            }
            const closeTeaModal = () => {
                teaModalContent.classList.add('translate-y-full');
                setTimeout(() => {
                    teaModal.classList.add('hidden');
                    teaForm.reset();
                    anxietyValue.textContent = "6"; // Reset slider value display
                }, 300);
            }
            
            teaForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(teaForm);
                const socialInteractions = [];
                formData.getAll('socialInteractions').forEach(i => socialInteractions.push(i));
                const sensoryTriggers = [];
                formData.getAll('sensoryTriggers').forEach(t => sensoryTriggers.push(t));

                const newRecord = {
                    id: Date.now(),
                    datetime: new Date().toISOString(),
                    mood: formData.get('mood'),
                    anxietyLevel: formData.get('anxietyLevel'),
                    emotionNotes: formData.get('emotionNotes'),
                    socialInteractions: socialInteractions,
                    socialNotes: formData.get('socialNotes'),
                    sensoryOverload: formData.get('sensoryOverload'),
                    sensoryTriggers: sensoryTriggers,
                    sensoryNotes: formData.get('sensoryNotes'),
                    routineChange: formData.get('routineChange'),
                    changeHandling: formData.get('changeHandling'),
                    routineNotes: formData.get('routineNotes'),
                    sleepQuality: formData.get('sleepQuality'),
                    sleepHours: formData.get('sleepHours'),
                    appetite: formData.get('appetite'),
                    foodNotes: formData.get('foodNotes'),
                    stimming: formData.get('stimming'),
                    specialInterest: formData.get('specialInterest'),
                    positiveMoment: formData.get('positiveMoment'),
                };
                state.teaRecords.push(newRecord);
                closeTeaModal();
                renderAll();
            });


            const medModal = document.getElementById('med-modal');
            const medModalContent = medModal.querySelector('.bg-white');
            const medForm = document.getElementById('med-form');
            const headerAddBtn = document.getElementById('add-med-btn-header');

            const addTimeInput = (time = '') => {
                const container = document.getElementById('times-container');
                const newTimeDiv = document.createElement('div');
                newTimeDiv.className = 'flex items-center gap-2';
                newTimeDiv.innerHTML = `
                    <input type="time" class="form-input flex-1" value="${time}" required>
                    <button type="button" class="remove-time-btn text-red-400 hover:text-red-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x-circle"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>
                    </button>
                `;
                container.appendChild(newTimeDiv);
                newTimeDiv.querySelector('.remove-time-btn').addEventListener('click', () => {
                    newTimeDiv.remove();
                    if (container.children.length === 0) {
                        addTimeInput(); // Asegura que siempre haya al menos un input
                    }
                });
            };


            const openMedModal = () => {
                medModal.classList.remove('hidden');
                document.getElementById('times-container').innerHTML = ''; // Limpia horarios anteriores
                addTimeInput(); // Agrega el primer input de hora por defecto
                setTimeout(() => medModalContent.classList.remove('translate-y-full'), 10);
            }
            const closeMedModal = () => {
                medModalContent.classList.add('translate-y-full');
                setTimeout(() => {
                    medModal.classList.add('hidden');
                    medForm.reset(); // Resetea el formulario al cerrar
                }, 300);
            }
            
            medForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(medForm);
                const times = [];
                document.querySelectorAll('#times-container input[type="time"]').forEach(input => {
                    if (input.value) {
                        // Convertir a formato 12 horas (AM/PM) para mostrar
                        const [hour, minute] = input.value.split(':');
                        const h = parseInt(hour, 10);
                        const ampm = h >= 12 ? 'PM' : 'AM';
                        const displayHour = h % 12 || 12;
                        times.push(`${displayHour.toString().padStart(2, '0')}:${minute} ${ampm}`);
                    }
                });

                if(times.length === 0) {
                    alert("Por favor, agregue al menos un horario.");
                    return;
                }

                const newMed = {
                    id: Date.now(),
                    name: formData.get('name'),
                    dose: formData.get('dose'),
                    frequency: formData.get('frequency'),
                    times: times,
                    notes: formData.get('notes'),
                    reminders: true,
                };
                state.medications.push(newMed);
                closeMedModal();
                renderAll();
            });

            const appointmentModal = document.getElementById('appointment-modal');
            const appointmentModalContent = appointmentModal.querySelector('.bg-white');
            const appointmentForm = document.getElementById('appointment-form');
            const headerAddAppointmentBtn = document.getElementById('add-appointment-btn-header');
            
            const openAppointmentModal = () => {
                appointmentModal.classList.remove('hidden');
                setTimeout(() => appointmentModalContent.classList.remove('translate-y-full'), 10);
            }
            const closeAppointmentModal = () => {
                appointmentModalContent.classList.add('translate-y-full');
                setTimeout(() => {
                    appointmentModal.classList.add('hidden');
                    appointmentForm.reset();
                }, 300);
            }

            appointmentForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(appointmentForm);
                const newAppointment = {
                    id: Date.now(),
                    reason: formData.get('reason'),
                    doctor: formData.get('doctor'),
                    datetime: `${formData.get('date')}T${formData.get('time')}`,
                    location: formData.get('location'),
                    companion: formData.get('companion'),
                    reminders: formData.get('reminders') === 'on'
                };
                state.appointments.push(newAppointment);
                closeAppointmentModal();
                renderAll();
            });

            // --- LÓGICA MODAL BCM ---
            const bcmModal = document.getElementById('bcm-modal');
            const bcmModalContent = bcmModal.querySelector('.bg-white');
            const bcmForm = document.getElementById('bcm-form');

            const openBcmModal = () => {
                bcmModal.classList.remove('hidden');
                setTimeout(() => bcmModalContent.classList.remove('translate-y-full'), 10);
            }
            const closeBcmModal = () => {
                bcmModalContent.classList.add('translate-y-full');
                setTimeout(() => {
                    bcmModal.classList.add('hidden');
                    bcmForm.reset();
                }, 300);
            }
            
            bcmForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(bcmForm);
                const newWeight = formData.get('pesoActual');
                const newLiquid = formData.get('liquido');

                if (newWeight) {
                    state.bcm.pesoActual = parseFloat(newWeight);
                }
                if (newLiquid) {
                    const now = new Date();
                    state.bcm.records.push({
                        time: now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
                        amount: parseInt(newLiquid)
                    });
                }
                
                if (state.bcm.pesoSeco === null) {
                    state.bcm.pesoSeco = 0; 
                    state.bcm.limiteDiario = 800; 
                }

                closeBcmModal();
                renderAll();
            });


            // --- LÓGICA DE NOTIFICACIONES ---
            const toast = document.getElementById('notification-toast');

            const showNotification = (title, body) => {
                document.getElementById('toast-title').textContent = title;
                document.getElementById('toast-body').textContent = body;
                toast.classList.remove('hidden');
                setTimeout(() => toast.classList.add('hidden'), 5000);
            };

            const checkReminders = () => {
                const now = new Date();
                const currentMinutes = now.getHours() * 60 + now.getMinutes();

                state.medications.forEach(med => {
                    if (med.reminders) {
                        med.times.forEach(time => {
                            const [hours, minutes] = time.split(':').map(Number);
                            const medTimeMinutes = hours * 60 + minutes;
                            if (medTimeMinutes === currentMinutes) {
                                showNotification('¡Hora del medicamento!', `Es hora de tomar tu ${med.name} (${med.dose}).`);
                            }
                        });
                    }
                });
            };

            const getNextMedication = () => {
                const now = new Date();
                let nextTake = null;

                state.medications.forEach(med => {
                    med.times.forEach(time => {
                        const [hours, minutes] = time.split(':').map(Number);
                        const takeTime = new Date();
                        takeTime.setHours(hours, minutes, 0, 0);

                        if (takeTime < now) {
                            takeTime.setDate(takeTime.getDate() + 1);
                        }

                        if (!nextTake || takeTime < nextTake.nextTake) {
                            nextTake = { med: med, time: time, nextTake: takeTime };
                        }
                    });
                });
                return nextTake;
            };

            // --- INICIALIZACIÓN ---
            const setupEventListeners = () => {
                closeMenuBtn.addEventListener('click', toggleMenu);
                menuOverlay.addEventListener('click', toggleMenu);
                
                sideMenuItems.forEach(item => {
                    item.addEventListener('click', (e) => {
                        e.preventDefault();
                        navigateTo(item.dataset.page);
                    });
                });

                document.getElementById('login-btn').addEventListener('click', handleLogin);
                document.getElementById('guest-login-btn').addEventListener('click', handleLogin);
                document.getElementById('logout-btn').addEventListener('click', () => {
                     navigateTo('login-screen');
                });
                document.getElementById('create-user-btn').addEventListener('click', () => {
                    navigateTo('create-user-screen');
                });
                document.getElementById('back-to-login-btn').addEventListener('click', () => {
                    navigateTo('login-screen');
                });

                headerAddBtn.addEventListener('click', openMedModal);
                document.getElementById('add-time-btn').addEventListener('click', () => addTimeInput());
                document.getElementById('cancel-med-modal').addEventListener('click', closeMedModal);
                document.getElementById('cancel-med-modal-2').addEventListener('click', closeMedModal);
                
                headerAddAppointmentBtn.addEventListener('click', openAppointmentModal);
                document.getElementById('cancel-appointment-modal').addEventListener('click', closeAppointmentModal);
                document.getElementById('cancel-appointment-modal-2').addEventListener('click', closeAppointmentModal);

                // Listeners para el nuevo modal de contacto
                document.getElementById('cancel-contact-modal').addEventListener('click', closeContactModal);
                document.getElementById('cancel-contact-modal-2').addEventListener('click', closeContactModal);

                // Listeners para el nuevo modal de diabetes
                document.getElementById('cancel-diabetes-modal').addEventListener('click', closeDiabetesModal);
                document.getElementById('cancel-diabetes-modal-2').addEventListener('click', closeDiabetesModal);
                
                // Listeners para el nuevo modal de artritis
                document.getElementById('cancel-arthritis-modal').addEventListener('click', closeArthritisModal);
                document.getElementById('cancel-arthritis-modal-2').addEventListener('click', closeArthritisModal);

                // Listeners para el nuevo modal de TEA
                document.getElementById('cancel-tea-modal').addEventListener('click', closeTeaModal);
                document.getElementById('cancel-tea-modal-2').addEventListener('click', closeTeaModal);

                document.getElementById('cancel-bcm-modal').addEventListener('click', closeBcmModal);
                document.getElementById('cancel-bcm-modal-2').addEventListener('click', closeBcmModal);

                document.getElementById('close-toast').addEventListener('click', () => toast.classList.add('hidden'));
            };

            setupEventListeners();
            navigateTo('login-screen');

        });